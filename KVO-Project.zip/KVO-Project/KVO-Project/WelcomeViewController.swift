//
//  ViewController.swift
//  KVO-Project
//
//  Created by Eric Davenport on 4/7/20.
//  Copyright © 2020 Eric Davenport. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
  
  @IBOutlet weak var welcomeLabel: UILabel!
  
  @IBOutlet weak var iconImageView: UIImageView!
  

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}

