//
//  SettingsViewController.swift
//  KVO-Project
//
//  Created by Eric Davenport on 4/7/20.
//  Copyright © 2020 Eric Davenport. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
  
  @IBOutlet weak var fontSizeLabel: UILabel!
  @IBOutlet weak var pickerView: UIPickerView!
  
  // datat for the picker view
  private let iconNames = ["sun.haze.fill", "moon", "globe", "icloud"] // SFSymbol image names e.g moon
  
  override func viewDidLoad() {
    super.viewDidLoad()
    configurePickerView()
  }
  
  private func configurePickerView() {
    pickerView.delegate = self
    pickerView.dataSource = self
  }
  
  
  @IBAction func sliderChanged(_ sender: UISlider) {
  }
  
  
}

extension SettingsViewController: UIPickerViewDataSource {
  func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1  // number of columns
  }
  
  func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return iconNames.count  // number of rows
  }
}

extension SettingsViewController: UIPickerViewDelegate {
  func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    return iconNames[row]   // indexPath.row
  }
}
